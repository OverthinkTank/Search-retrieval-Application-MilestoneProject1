package cecs429.documents;

public class AllSites {
	String body;
	String url;
	String title;
}
